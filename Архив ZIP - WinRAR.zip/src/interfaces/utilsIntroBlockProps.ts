export interface UtilsIntroBlockProps {
    title: string
}