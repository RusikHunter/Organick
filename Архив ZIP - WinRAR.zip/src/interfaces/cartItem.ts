export interface CartItem {
    id: number,
    count: number
}