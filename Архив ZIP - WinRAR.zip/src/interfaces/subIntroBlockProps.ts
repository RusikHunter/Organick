export interface SubIntroBlockProps {
    title: string,
    backgroundImageURL: string
    blurredBackgroundImageURL: string
}