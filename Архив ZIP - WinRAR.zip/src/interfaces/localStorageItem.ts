export interface LocalStorageItem {
    id: number
    productCount: number
}