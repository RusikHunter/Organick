export interface NewsWrapProps {
    defaultNewsCount: number
}