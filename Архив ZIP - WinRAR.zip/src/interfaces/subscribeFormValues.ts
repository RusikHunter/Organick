export interface SubscribeFormValues {
    email: string
}