export interface IntroBlockProps {
    content: React.ReactNode
    backgroundImageURL: string
    blurredBackgroundImageURL: string
}