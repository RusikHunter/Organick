export interface TeamSectionProps {
    defaultExpertsCount: number
}