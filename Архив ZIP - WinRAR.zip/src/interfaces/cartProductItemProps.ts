import type { CartItem } from "./cartItem"

export interface CartProductItemProps {
    cartItem: CartItem
}