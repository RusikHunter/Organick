import type { Post } from "./post"

export interface NewsCardProps {
    post: Post
}