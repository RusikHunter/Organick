export interface PaymentFormValues {
    full_name: string
    email: string
    company: string
    address: string,
    card: string,
    date: string,
    cvv: string
}