export interface LocationFormValues {
    full_name: string
    email: string
    company: string
    subject: string
    message: string
}