export interface Post {
    id: number,
    title: string,
    description: string,
    author: string,
    date: string,
    content: string,
    imageURL: string
}