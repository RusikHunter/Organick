export interface PortfolioItemCardProps {
    id: number
    title: string
    type: string
    backgroundImageURL: string
    backgroundBlurredImageURL: string
    className: string
}