import NotFoundSection from "../../components/NotFoundSection/NotFoundSection"

function NotFoundPage() {
    return (
        <>
            <NotFoundSection />
        </>
    )
}

export default NotFoundPage