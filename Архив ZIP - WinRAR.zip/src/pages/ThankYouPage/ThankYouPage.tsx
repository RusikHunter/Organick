import ThankYouSection from "../../components/ThankYouSection/ThankYouSection"

function ThankYouPage() {
    return (
        <>
            <ThankYouSection />
        </>
    )
}

export default ThankYouPage