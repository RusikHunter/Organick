function Loader() {
    // todo --> styles
    return (
        <p>Loading...</p>
    )
}

export default Loader