import "./ProductCard.scss"
import { Link } from "react-router-dom"
import type { ProductCardProps } from "../../interfaces/productCardProps"

import ProductBlurredImage from "../../assets/images/background/product-blurred.webp"
import { LazyLoadImage } from 'react-lazy-load-image-component'
import 'react-lazy-load-image-component/src/effects/blur.css'

function ProductCard({ isCartItem, productData }: ProductCardProps) {
    return (
        <Link
            to={`/shop/${productData.id}`}
            className={`product-card${isCartItem ? ' product-card--cart-item' : ''}`}
            tabIndex={isCartItem ? -1 : 0}
            style={{ ...(isCartItem ? { transform: "none" } : {}) }}
        >
            <span className="product-card__category">{productData.type}</span>

            <LazyLoadImage
                src={productData.imageURL}
                alt="Fresh Banana"
                className="product-card__image"
                width={336}
                height={375}
                effect="blur"
                placeholderSrc={ProductBlurredImage}
            />

            <h6 className="product-card__title">{productData.title}</h6>

            <div className="product-card__price-wrap">
                <span className="product-card__price--sale"><s>{Number.isInteger(productData.price) ? `${productData.price}.00` : productData.price}$</s></span>

                <span className="product-card__price">{Number.isInteger(productData.discountPrice) ? `${productData.discountPrice}.00` : productData.discountPrice}$</span>

                <div className="product-card__rate">
                    {Array.from({ length: 5 }).map((_, index) => (
                        <svg
                            key={index}
                            width="15"
                            height="14"
                            viewBox="0 0 15 14"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className={`${index + 1 > productData.rating ? 'product-card__star--empty' : ''}`}
                        >
                            <path d="M6.67806 1.09367C6.98566 0.189974 8.26378 0.189977 8.57138 1.09367L9.5549 3.98313C9.69285 4.3884 10.0735 4.66091 10.5016 4.66091H13.5818C14.5617 4.66091 14.9569 5.92416 14.1517 6.48263L11.7409 8.15456C11.3741 8.40901 11.2203 8.87584 11.3642 9.29851L12.3036 12.0586C12.6145 12.9718 11.5798 13.7523 10.7871 13.2025L8.19462 11.4046C7.85187 11.1668 7.39758 11.1668 7.05483 11.4046L4.46235 13.2025C3.66969 13.7523 2.63496 12.9718 2.9458 12.0586L3.88528 9.29851C4.02915 8.87584 3.87539 8.40901 3.50851 8.15456L1.09777 6.48263C0.292535 5.92416 0.687722 4.66091 1.66767 4.66091H4.74788C5.17598 4.66091 5.55659 4.3884 5.69454 3.98313L6.67806 1.09367Z" fill="#FFA858" />
                        </svg>
                    ))}
                </div>
            </div>
        </ Link >
    )
}

export default ProductCard