export const SERVICE_ID = "service_z4zipxo"
export const SERVICE_ID_ORDERS = "service_tq754ns"

export const TEMPLATE_ID_SUBSCRIBE = "template_jlxi2uz"
export const TEMPLATE_ID_LOCATION = "template_oeeuum3"
export const TEMPLATE_ID_ORDERS = "template_8d0jzcf"

export const PUBLIC_KEY = "Mvb1CzSkGl7ku8kuQ"
export const PUBLIC_KEY_ORDERS = "VBiChuXn3PIuChD8o"