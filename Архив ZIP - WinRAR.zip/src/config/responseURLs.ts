export const productsURL = "https://685bbb3189952852c2dabaa6.mockapi.io/products"
export const postsURL = "https://685bbb3189952852c2dabaa6.mockapi.io/posts"