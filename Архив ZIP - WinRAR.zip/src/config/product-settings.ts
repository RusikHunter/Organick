export const MIN_PRODUCT_COUNT = 0
export const MAX_PRODUCT_COUNT = 100