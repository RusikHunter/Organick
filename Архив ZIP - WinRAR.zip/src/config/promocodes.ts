export const promocodes: string[] = [
    "A7C9ZB1K",
    "Q2D4MNP5",
    "X1T9EJK3",
    "L8ZK2RWA",
    "YH3N2MC9",
    "P4TGAK92",
    "3VJZ1LMA",
    "WQK9Z5N1",
    "N4JXE8KT",
    "BRL7ZC93"
]